export const environment = {
  production: false,
  api: 'http://localhost:54791/api/heroes/'
};
