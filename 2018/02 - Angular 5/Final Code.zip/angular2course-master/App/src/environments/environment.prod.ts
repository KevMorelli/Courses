export const environment = {
  production: true,
  api: 'https://acntourofheroes.azurewebsites.net/api/heroes/'
};